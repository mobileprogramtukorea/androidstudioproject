package com.example.final_project.checklist

import androidx.fragment.app.Fragment
import com.example.final_project.R

class CheckListFragment: Fragment(R.layout.fragment_checklist) {
}