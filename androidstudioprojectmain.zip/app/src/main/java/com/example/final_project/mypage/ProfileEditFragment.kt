package com.example.final_project.mypage

import androidx.fragment.app.Fragment
import com.example.final_project.R

class ProfileEditFragment: Fragment(R.layout.fragment_profileedit) {

}