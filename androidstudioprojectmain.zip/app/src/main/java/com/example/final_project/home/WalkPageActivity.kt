package com.example.final_project.home

class WalkPageActivity {
}