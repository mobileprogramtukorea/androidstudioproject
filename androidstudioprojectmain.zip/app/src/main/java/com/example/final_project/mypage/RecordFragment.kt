package com.example.final_project.mypage

import androidx.fragment.app.Fragment
import com.example.final_project.R

class RecordFragment: Fragment(R.layout.fragment_record) {

}